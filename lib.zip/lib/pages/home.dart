import 'package:control_tareas/data/task.dart';
import 'package:control_tareas/pages/new_task.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<Task> tasks = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Control de tareas"),
      ),
      body: fullBody(),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final task = await Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const NewTaskPage()))
              as Task?;

          if (task != null) {
            setState(() {
              tasks.add(task);
              tasks.sort((a, b) => a.compareTo(b));
            });
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget fullBody() {
    return ListView.builder(
        itemBuilder: (context, index) {
          return ListTile(
            tileColor: tasks[index].isDone ? Colors.grey[300] : Colors.grey[50],
            title: Text(
              tasks[index].description,
            ),
            subtitle: Text(tasks[index].date.toString().split(" ")[0]),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              Text(tasks[index].priorityName),
              const SizedBox(width: 10),
              Checkbox(
                  value: tasks[index].isDone,
                  onChanged: (value) {
                    setState(() {
                      tasks[index].isDone = value!;
                    });
                  })
            ]),
            leading: Text(
              tasks[index].title,
            ),
            onTap: () {
              showTask(context, tasks[index]);
            },
            onLongPress: () {
              setState(() {
                tasks.removeAt(index);
              });
            },
          );
        },
        itemCount: tasks.length);
  }

  void showTask(BuildContext context, Task task) {
    showDialog(
        context: context,
        builder: (context) =>
            StatefulBuilder(builder: (context, setLocalState) {
              return AlertDialog(
                title: Center(child: Text(task.title)),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(task.description),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(task.date.toString().split(" ")[0]),
                        Text(task.priorityName),
                        Checkbox(
                            value: task.isDone,
                            onChanged: (value) {
                              setState(() {
                                setLocalState(() {
                                  task.isDone = value!;
                                });
                              });
                            })
                      ],
                    ),
                  ],
                ),
                actions: [
                  TextButton(
                      style: TextButton.styleFrom(foregroundColor: Colors.red),
                      onPressed: () {
                        setState(() {
                          tasks.remove(task);
                        });
                        Navigator.of(context).pop();
                      },
                      child: const Text("Eliminar")),
                  TextButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: const Text("Aceptar")),
                ],
              );
            }));
  }
}
